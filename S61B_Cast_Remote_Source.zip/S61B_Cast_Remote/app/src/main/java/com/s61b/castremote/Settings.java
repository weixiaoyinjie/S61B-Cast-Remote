package com.s61b.castremote;

import android.content.Context;
import android.content.SharedPreferences;
import java.net.InetAddress;
import java.util.regex.Pattern;

final class Settings {
    private Settings() {}
    private static final String NAME = "settings";
    static String host(Context context) {
        return prefs(context).getString("host", "192.168.0.65");
    }
    static void saveHost(Context context, String host) {
        prefs(context).edit().putString("host", host).apply();
    }
    static int volume(Context context) {
        return prefs(context).getInt("lastVolume", -1);
    }
    static boolean muted(Context context) {
        return prefs(context).getBoolean("lastMuted", false);
    }
    static void saveStatus(Context context, CastClient.Status status) {
        prefs(context).edit().putInt("lastVolume", status.percent)
                .putBoolean("lastMuted", status.muted).apply();
    }
    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(NAME, Context.MODE_PRIVATE);
    }
    /** No hostnames or public addresses; controls stay on the user's local network. */
    static String validateHost(String input) throws Exception {
        String s = input.trim();
        if (!Pattern.matches("(?:[0-9]{1,3}\\.){3}[0-9]{1,3}", s)) {
            throw new IllegalArgumentException("请输入局域网 IPv4 地址，例如 192.168.0.65");
        }
        String[] pieces = s.split("\\.");
        for (String part : pieces) {
            if (Integer.parseInt(part) > 255) throw new IllegalArgumentException("无效的 IP 地址");
        }
        InetAddress address = InetAddress.getByName(s);
        if (!(address.isSiteLocalAddress() || address.isLinkLocalAddress())) {
            throw new IllegalArgumentException("只能连接局域网私有 IP 地址");
        }
        return s;
    }
}
