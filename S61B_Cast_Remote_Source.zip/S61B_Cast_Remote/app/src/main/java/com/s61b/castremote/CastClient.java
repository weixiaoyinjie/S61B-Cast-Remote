package com.s61b.castremote;

import org.json.JSONObject;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

/**
 * Experimental local-only Cast V2 transport (port 8009).
 * Does not launch media apps or change soundbar input. Uses system receiver volume only.
 * Cast receivers commonly ship self-signed TLS certificates, so this deliberately does not
 * authenticate their certificate. Use ONLY on a trusted home LAN with a known private IP.
 */
final class CastClient implements AutoCloseable {
    private static final String CONNECTION = "urn:x-cast:com.google.cast.tp.connection";
    private static final String RECEIVER = "urn:x-cast:com.google.cast.receiver";
    private static final String HEARTBEAT = "urn:x-cast:com.google.cast.tp.heartbeat";
    private final SSLSocket socket;
    private final DataInputStream in;
    private final DataOutputStream out;
    private int requestId = 1;

    static final class Status {
        final int percent;
        final boolean muted;
        Status(int percent, boolean muted) {
            this.percent = Math.max(0, Math.min(100, percent));
            this.muted = muted;
        }
    }

    CastClient(String host) throws Exception {
        final String safeHost = Settings.validateHost(host);
        TrustManager trustLocalSelfSigned = new X509TrustManager() {
            @Override public void checkClientTrusted(X509Certificate[] chain, String authType) { }
            @Override public void checkServerTrusted(X509Certificate[] chain, String authType) { }
            @Override public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
        };
        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(null, new TrustManager[]{trustLocalSelfSigned}, new SecureRandom());
        SSLSocketFactory factory = sslContext.getSocketFactory();
        SSLSocket s = (SSLSocket) factory.createSocket();
        try {
            s.connect(new InetSocketAddress(safeHost, 8009), 2500);
            s.setSoTimeout(4000);
            s.startHandshake();
        } catch (Exception ex) {
            try { s.close(); } catch (Exception ignored) { }
            throw ex;
        }
        socket = s;
        in = new DataInputStream(s.getInputStream());
        out = new DataOutputStream(s.getOutputStream());
        send(CONNECTION, new JSONObject().put("type", "CONNECT").put("origin", new JSONObject()));
    }

    private void send(String ns, JSONObject value) throws Exception {
        byte[] bytes = CastWire.encode(ns, value.toString());
        out.writeInt(bytes.length);
        out.write(bytes);
        out.flush();
    }

    Status getStatus() throws Exception {
        send(RECEIVER, new JSONObject().put("type", "GET_STATUS").put("requestId", requestId++));
        for (int i = 0; i < 12; i++) {
            int n = in.readInt();
            if (n < 1 || n > 1024 * 1024) throw new IOException("Invalid Cast frame length: " + n);
            byte[] data = new byte[n];
            in.readFully(data);
            CastWire.Envelope envelope = CastWire.decode(data);
            if (HEARTBEAT.equals(envelope.namespace)) {
                JSONObject heartbeat = new JSONObject(envelope.payload);
                if ("PING".equals(heartbeat.optString("type"))) {
                    send(HEARTBEAT, new JSONObject().put("type", "PONG"));
                }
                continue;
            }
            if (!RECEIVER.equals(envelope.namespace)) continue;
            JSONObject json = new JSONObject(envelope.payload);
            if (!"RECEIVER_STATUS".equals(json.optString("type"))) continue;
            JSONObject status = json.optJSONObject("status");
            if (status == null) continue;
            JSONObject vol = status.optJSONObject("volume");
            if (vol == null || !vol.has("level")) continue;
            double level = vol.optDouble("level", -1);
            if (level < 0 || level > 1) throw new IOException("Receiver reported invalid volume level");
            return new Status((int)Math.round(level * 100.0), vol.optBoolean("muted", false));
        }
        throw new EOFException("S61B did not return its Cast receiver volume status");
    }

    void setVolume(int percent) throws Exception {
        double level = Math.max(0, Math.min(100, percent)) / 100.0;
        send(RECEIVER, new JSONObject().put("type", "SET_VOLUME")
            .put("requestId", requestId++)
            .put("volume", new JSONObject().put("level", level)));
    }
    void setMute(boolean mute) throws Exception {
        send(RECEIVER, new JSONObject().put("type", "SET_VOLUME")
            .put("requestId", requestId++)
            .put("volume", new JSONObject().put("muted", mute)));
    }
    @Override public void close() throws IOException { socket.close(); }
}
