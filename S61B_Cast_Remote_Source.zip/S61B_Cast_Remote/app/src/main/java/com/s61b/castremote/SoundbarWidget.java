package com.s61b.castremote;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

/** Home-screen widget. Buttons work without opening SmartThings or this activity. */
public class SoundbarWidget extends AppWidgetProvider {
    private static final String ACTION_PREFIX = "com.s61b.castremote.ACTION_";
    private static final String EXTRA_OP = "OP";

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) manager.updateAppWidget(id, view(context, null));
    }
    @Override public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (intent.getAction() == null || !intent.getAction().startsWith(ACTION_PREFIX)) return;
        String op = intent.getStringExtra(EXTRA_OP);
        SoundbarActions.Action action;
        try { action = SoundbarActions.Action.valueOf(op == null ? "READ" : op); }
        catch (IllegalArgumentException ignored) { return; }
        final PendingResult pending = goAsync();
        new Thread(() -> {
            try {
                render(context, "连接中…");
                SoundbarActions.Result result = SoundbarActions.execute(context, action, 0);
                if (result.note.contains("没有报告")) render(context, "请检查");
                else render(context, null);
            } catch (Exception ex) {
                render(context, "连接失败");
            } finally { pending.finish(); }
        }, "cast-widget-" + op).start();
    }
    static void render(Context context, String warning) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        ComponentName component = new ComponentName(context, SoundbarWidget.class);
        manager.updateAppWidget(component, view(context, warning));
    }
    private static RemoteViews view(Context ctx, String warning) {
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_soundbar);
        int vol = Settings.volume(ctx);
        String status = warning != null ? warning : (vol < 0 ? "--%" : vol + "%" + (Settings.muted(ctx) ? " 静音" : ""));
        v.setTextViewText(R.id.w_status, status);
        Intent activity = new Intent(ctx, MainActivity.class);
        activity.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        v.setOnClickPendingIntent(R.id.w_title,
                PendingIntent.getActivity(ctx, 101, activity, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        v.setOnClickPendingIntent(R.id.w_down, request(ctx, SoundbarActions.Action.DOWN, 102));
        v.setOnClickPendingIntent(R.id.w_up, request(ctx, SoundbarActions.Action.UP, 103));
        v.setOnClickPendingIntent(R.id.w_mute, request(ctx, SoundbarActions.Action.MUTE, 104));
        v.setOnClickPendingIntent(R.id.w_refresh, request(ctx, SoundbarActions.Action.READ, 105));
        return v;
    }
    private static PendingIntent request(Context ctx, SoundbarActions.Action action, int requestCode) {
        Intent intent = new Intent(ctx, SoundbarWidget.class)
                .setAction(ACTION_PREFIX + action.name())
                .putExtra(EXTRA_OP, action.name());
        return PendingIntent.getBroadcast(ctx, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
