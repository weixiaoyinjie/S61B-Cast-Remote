package com.s61b.castremote;

import android.content.Context;

/** Performs READ or receiver-level Cast control on a background thread only. */
final class SoundbarActions {
    enum Action { READ, UP, DOWN, MUTE, SET }
    static final class Result {
        final CastClient.Status status;
        final String note;
        Result(CastClient.Status status, String note) { this.status = status; this.note = note; }
    }
    private SoundbarActions() {}

    static Result execute(Context ctx, Action action, int target) throws Exception {
        String ip = Settings.validateHost(Settings.host(ctx));
        CastClient.Status before;
        int requested = -1;
        boolean newMute = false;
        try (CastClient cast = new CastClient(ip)) {
            before = cast.getStatus();
            if (action == Action.READ) {
                Settings.saveStatus(ctx, before);
                return new Result(before, "已读取 S61B Cast 音量状态");
            }
            if (action == Action.UP || action == Action.DOWN || action == Action.SET) {
                requested = action == Action.SET ? Math.max(0, Math.min(100, target))
                        : Math.max(0, Math.min(100, before.percent + (action == Action.UP ? 1 : -1)));
                cast.setVolume(requested);
            } else if (action == Action.MUTE) {
                newMute = !before.muted;
                cast.setMute(newMute);
            }
        }
        // Confirm on a new Cast V2 connection rather than displaying a guessed success.
        Thread.sleep(250);
        CastClient.Status after;
        try (CastClient cast = new CastClient(ip)) {
            after = cast.getStatus();
        }
        Settings.saveStatus(ctx, after);
        boolean verified = action == Action.MUTE ? after.muted == newMute
                : Math.abs(after.percent - requested) <= 1
                   && (requested == before.percent || after.percent != before.percent);
        String note = verified ? "设备已返回更新后的状态" :
                "已发送指令，但设备没有报告预期变化；可能不支持此控制方式";
        return new Result(after, note);
    }
}
