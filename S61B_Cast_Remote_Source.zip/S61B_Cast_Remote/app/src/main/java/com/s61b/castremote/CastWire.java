package com.s61b.castremote;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

/** Minimal subset of Google's Cast V2 protobuf envelope, no external dependencies. */
final class CastWire {
    private CastWire() {}
    static final class Envelope {
        final String namespace;
        final String payload;
        Envelope(String namespace, String payload) { this.namespace = namespace; this.payload = payload; }
    }
    static byte[] encode(String namespace, String json) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        varintField(out, 1, 0); // CASTV2_1_0
        stringField(out, 2, "sender-0");
        stringField(out, 3, "receiver-0");
        stringField(out, 4, namespace);
        varintField(out, 5, 0); // STRING
        stringField(out, 6, json);
        return out.toByteArray();
    }
    private static void varintField(ByteArrayOutputStream out, int field, int value) {
        writeVarint(out, (field << 3)); writeVarint(out, value);
    }
    private static void stringField(ByteArrayOutputStream out, int field, String string) {
        byte[] bytes = string.getBytes(StandardCharsets.UTF_8);
        writeVarint(out, (field << 3) | 2);
        writeVarint(out, bytes.length);
        out.write(bytes, 0, bytes.length);
    }
    static void writeVarint(ByteArrayOutputStream out, int value) {
        while ((value & ~127) != 0) {
            out.write((value & 127) | 128); value >>>= 7;
        }
        out.write(value);
    }
    static Envelope decode(byte[] bytes) throws IOException {
        int[] p = {0};
        String namespace = "";
        String payload = "";
        while (p[0] < bytes.length) {
            long tag = readVarint(bytes, p);
            int number = (int) (tag >>> 3);
            int wireType = (int) (tag & 7);
            if (wireType == 0) {
                readVarint(bytes, p);
            } else if (wireType == 2) {
                long len = readVarint(bytes, p);
                if (len < 0 || len > bytes.length - p[0]) throw new IOException("Bad Cast message length");
                int start = p[0];
                p[0] += (int) len;
                if (number == 4) namespace = new String(bytes, start, (int) len, StandardCharsets.UTF_8);
                if (number == 6) payload = new String(bytes, start, (int) len, StandardCharsets.UTF_8);
            } else if (wireType == 1) {
                if (bytes.length - p[0] < 8) throw new IOException("Truncated double");
                p[0] += 8;
            } else if (wireType == 5) {
                if (bytes.length - p[0] < 4) throw new IOException("Truncated fixed32");
                p[0] += 4;
            } else {
                throw new IOException("Unsupported protobuf wire type " + wireType);
            }
        }
        return new Envelope(namespace, payload);
    }
    private static long readVarint(byte[] bytes, int[] p) throws IOException {
        long result = 0;
        for (int shift = 0; shift < 64; shift += 7) {
            if (p[0] >= bytes.length) throw new IOException("Truncated varint");
            int b = bytes[p[0]++] & 0xFF;
            result |= ((long)(b & 127)) << shift;
            if ((b & 128) == 0) return result;
        }
        throw new IOException("Invalid varint");
    }
}
