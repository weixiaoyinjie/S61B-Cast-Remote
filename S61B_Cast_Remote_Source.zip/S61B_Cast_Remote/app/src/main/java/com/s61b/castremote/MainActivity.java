package com.s61b.castremote;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.res.ColorStateList;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Lightweight AMOLED controller with real LAN readback (not a UI mockup). */
public class MainActivity extends Activity {
    private static final int BLUE = Color.rgb(58, 130, 255);
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private TextView volumeLabel, statusLabel;
    private SeekBar volumeSlider;
    private EditText ipInput;
    private Button upButton, downButton, muteButton, refreshButton;
    private boolean busy;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.BLACK);
        LinearLayout root = new LinearLayout(this);
        root.setPadding(dp(22), dp(25), dp(22), dp(20));
        root.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(root);
        setContentView(scroll);

        TextView header = label("S61B Remote", 28, Color.WHITE, true);
        root.addView(header);
        root.addView(label("Google Cast 局域网 · 测试版", 14, 0xFF888A91, false));
        gap(root, 22);

        LinearLayout network = card();
        root.addView(network);
        network.addView(label("音响局域网 IP", 15, 0xFFBABCC4, false));
        ipInput = new EditText(this);
        ipInput.setSingleLine(true);
        ipInput.setText(Settings.host(this));
        ipInput.setTextColor(Color.WHITE);
        ipInput.setHintTextColor(0xFF999999);
        ipInput.setInputType(android.text.InputType.TYPE_CLASS_PHONE);
        network.addView(ipInput, new LinearLayout.LayoutParams(-1, dp(52)));
        Button saveIp = button("保存 IP", 0xFF31343A);
        network.addView(saveIp);
        saveIp.setOnClickListener(v -> {
            try {
                Settings.saveHost(this, Settings.validateHost(ipInput.getText().toString()));
                statusLabel.setText("已保存 IP，点击连接测试");
            } catch (Exception e) { statusLabel.setText(e.getMessage()); }
        });
        gap(root, 16);

        LinearLayout control = card();
        root.addView(control);
        control.addView(label("设备音量", 17, 0xFFE2E2E8, true));
        volumeLabel = label("--%", 40, Color.WHITE, true);
        volumeLabel.setGravity(Gravity.CENTER_HORIZONTAL);
        control.addView(volumeLabel);
        volumeSlider = new SeekBar(this);
        volumeSlider.setMax(100);
        volumeSlider.setProgress(Settings.volume(this) < 0 ? 0 : Settings.volume(this));
        volumeSlider.setProgressTintList(ColorStateList.valueOf(BLUE));
        volumeSlider.setThumbTintList(ColorStateList.valueOf(BLUE));
        control.addView(volumeSlider, new LinearLayout.LayoutParams(-1, dp(54)));
        volumeSlider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onStartTrackingTouch(SeekBar bar) { }
            @Override public void onProgressChanged(SeekBar bar, int value, boolean fromUser) {
                if (fromUser) volumeLabel.setText(value + "%");
            }
            @Override public void onStopTrackingTouch(SeekBar bar) {
                submit(SoundbarActions.Action.SET, bar.getProgress());
            }
        });
        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        control.addView(buttons);
        downButton = button("－ 1%", BLUE);
        upButton = button("＋ 1%", BLUE);
        addWeighted(buttons, downButton);
        addWeighted(buttons, upButton);
        downButton.setOnClickListener(v -> submit(SoundbarActions.Action.DOWN, 0));
        upButton.setOnClickListener(v -> submit(SoundbarActions.Action.UP, 0));
        muteButton = button("静音 / 取消静音", 0xFF31343A);
        LinearLayout.LayoutParams muteLp = new LinearLayout.LayoutParams(-1, dp(52));
        muteLp.topMargin = dp(10);
        control.addView(muteButton, muteLp);
        muteButton.setOnClickListener(v -> submit(SoundbarActions.Action.MUTE, 0));
        gap(root, 15);

        refreshButton = button("连接测试 / 刷新实际音量", 0xFF25272C);
        root.addView(refreshButton, new LinearLayout.LayoutParams(-1, dp(56)));
        refreshButton.setOnClickListener(v -> submit(SoundbarActions.Action.READ, 0));
        gap(root, 10);
        statusLabel = label("尚未连接", 14, 0xFFB9BBC5, false);
        statusLabel.setPadding(dp(4), dp(5), dp(4), dp(5));
        root.addView(statusLabel);
        gap(root, 22);
        root.addView(label("桌面长按空白处 → 小组件 → S61B Cast Remote。"
                + "\n小组件可直接点音量＋、音量－、静音。点击小组件标题可打开自由调节滑块。"
                + "\n\n此测试版只连接本地 8009 端口，不切换电视音源；能否作用于 S61B 的 ARC 音量，需实机确认。",
                13, 0xFF8B8C94, false));
        submit(SoundbarActions.Action.READ, 0);
    }

    private void submit(SoundbarActions.Action action, int target) {
        if (busy) return;
        busy = true;
        changeEnabled(false);
        statusLabel.setText("连接 S61B，等待实际状态…");
        executor.execute(() -> {
            try {
                SoundbarActions.Result result = SoundbarActions.execute(getApplicationContext(), action, target);
                main.post(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    volumeLabel.setText(result.status.percent + "%" + (result.status.muted ? " · 静音" : ""));
                    volumeSlider.setProgress(result.status.percent);
                    statusLabel.setText(result.note);
                    SoundbarWidget.render(getApplicationContext(), null);
                    busy = false;
                    changeEnabled(true);
                });
            } catch (Exception e) {
                main.post(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    String msg = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                    statusLabel.setText("连接失败：" + msg);
                    busy = false;
                    changeEnabled(true);
                });
            }
        });
    }
    private void changeEnabled(boolean available) {
        volumeSlider.setEnabled(available);
        downButton.setEnabled(available);
        upButton.setEnabled(available);
        muteButton.setEnabled(available);
        refreshButton.setEnabled(available);
    }
    @Override protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }
    private LinearLayout card() {
        LinearLayout card = new LinearLayout(this);
        card.setPadding(dp(17), dp(17), dp(17), dp(17));
        card.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF1B1C20);
        bg.setCornerRadius(dp(24));
        card.setBackground(bg);
        return card;
    }
    private TextView label(String value, int sp, int color, boolean strong) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setLineSpacing(dp(3), 1.1f);
        if (strong) v.setTypeface(null, Typeface.BOLD);
        return v;
    }
    private Button button(String title, int background) {
        Button v = new Button(this);
        v.setText(title);
        v.setAllCaps(false);
        v.setTextSize(15);
        v.setTextColor(Color.WHITE);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(background);
        bg.setCornerRadius(dp(16));
        v.setBackground(bg);
        return v;
    }
    private void addWeighted(LinearLayout row, View v) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(56), 1f);
        lp.leftMargin = dp(3);
        lp.rightMargin = dp(3);
        row.addView(v, lp);
    }
    private void gap(LinearLayout root, int dp) {
        root.addView(new View(this), new LinearLayout.LayoutParams(1, dp(dp)));
    }
    private int dp(float value) { return (int)(getResources().getDisplayMetrics().density * value + 0.5f); }
}
