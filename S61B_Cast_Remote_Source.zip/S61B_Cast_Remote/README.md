# S61B Cast Remote — 测试版

专门用于 Samsung HW-S61B 的 **局域网 Google Cast 音量控制可行性测试**。

## 已实现

- 默认 IP：`192.168.0.65`，可在 App 中修改、保存
- Cast V2（TLS/TCP 8009）原生协议，不需要 SmartThings token/API
- 读取当前 Cast 设备音量与静音状态（`GET_STATUS`）
- 自由拖动 0–100% 音量滑块（`SET_VOLUME`）
- 读取当前百分比后＋1%／－1%（不依赖 App 缓存值）
- 静音 / 取消静音
- Android 桌面小组件：`－` / `＋` / `静音` / `刷新`，点击标题打开自由滑块
- 不主动启动播放、不调用 CAST LAUNCH、不改音源
- 尝试重新读取设备状态，发现未变化时给出提示

## 重要限制

- **这是未经 Samsung HW-S61B 真机验证、也尚未成功完成 Gradle 构建的源代码。** 不保证第三方 Cast 客户端能操作这款型号在 D.IN/TV ARC 状态下的实际音量。
- 8009 可达不等于 Cast V2 一定允许接入；Google Home 可控制也不等于它与本 App 使用相同协议。
- 1% 是 Cast 音量百分比；S61B 实际硬件可调档位可能不是 1%。
- Android 桌面小组件本身不能直接提供类似 Activity 的连续拖动 SeekBar，因此用小组件＋/－，点击标题进入本 App 的自由音量滑块，**不会打开 SmartThings**。
- 不含电源功能：继续使用你已成功配置的 SmartThings 电源切换快捷方式。
- 连接只允许本地 IPv4 私有地址，不调用云端服务。
- Cast 设备一般使用自签名证书；此测试版 TLS 连接加密但**不验证接收设备证书身份**。只应在可信家庭局域网使用，勿端口转发到互联网。
- 手机与音响须在同一局域网，防火墙/AP 隔离不能阻止到 8009 的连接。

## GitHub 编译

1. 新建仓库 `S61B-Cast-Remote`。
2. 解压本 ZIP，将里面的文件**直接放在仓库根目录**（不要再多套一个文件夹），包括 `.github/workflows/build-apk.yml`。
3. 进入 GitHub `Actions > Build S61B Cast Remote APK > Run workflow`。
4. 编译成功后，打开本次运行的 `Artifacts` 下载 `S61B-Cast-Remote-debug-apk`；里面是 `app-debug.apk`。

GitHub Actions 使用 Java 17，Gradle 8.10.2、Android Gradle Plugin 8.7.3、SDK 35。

## 手机测试

1. 安装 APK，打开 App，确认 IP 地址正确。
2. 先点击“连接测试 / 刷新实际音量”；成功时应显示音响当前 Cast volume。
3. 把音量从低数值开始小幅调整，听实际 S61B 音量是否变化。务必留意 D.IN/TV ARC 是否保持不变。
4. 若成功，手机桌面长按空白处 > 小组件 > S61B Cast Remote，放入小组件。
5. 若提示 `连接失败` 或 `未报告预期变化`，截图错误文字反馈，不要反复发送未确认的音量指令。

## 技术

本工程没有外部 runtime 库；手工实现 Cast V2 protobuf envelope 的必要字段，使用 TLS socket，receiver namespace 的 `GET_STATUS` / `SET_VOLUME`。每条变化指令会读取当前状态，然后再发送，并尝试重新连接获取回执。

此代码仅操作自己拥有或获准管理的局域网设备。
